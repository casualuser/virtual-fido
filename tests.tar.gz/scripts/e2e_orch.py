import subprocess
import os
import signal
import sys
import time
import argparse

VM_USER = "ubuntu" # Default for Colima/UTM
VM_HOST = "192.168.64.6"
SSH_KEY = "~/.ssh/id_rsa" # Adjust if needed

def run_ssh_command(cmd, input_str=None):
    ssh_cmd = f"ssh -o StrictHostKeyChecking=no {VM_USER}@{VM_HOST} '{cmd}'"
    process = subprocess.Popen(
        ssh_cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        shell=True
    )
    stdout, stderr = process.communicate(input=input_str)
    return stdout.strip(), stderr.strip()

def run_host_command(cmd, input_str=None):
    process = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        shell=True
    )
    stdout, stderr = process.communicate(input=input_str)
    return stdout.strip(), stderr.strip()

def main():
    print("Starting E2E Orchestration (SSH Mode)...")
    
    # Check connectivity
    print(f"Checking connectivity to {VM_HOST}...")
    out, err = run_ssh_command("echo hello")
    if out != "hello":
        print(f"Failed to connect to VM: {err}")
        return

    print("Connected. Starting Relay on Guest...")
    # Start the relay in background on Guest? 
    # Actually, enforcing a strict request/response loop via SSH is easier if we
    # just run the 'playwright' script and intercept its IO?
    # But Playwright interacts with the *browser*, which triggers the HID request 
    # that 'virtual-fido' receives.
    
    # 1. Start 'virtual-fido online-only' on Guest 
    # We need it to print the request to stdout.
    
    # For now, let's assume the user runs the scripts manually as per the original plan
    # but uses this updated script to facilitate the piping if valid.
    # OR, we stick to the manual pipe loop for simplicity as requested by "retry and continue".
    # The user didn't explicitly ask for SSH automation, just "e2e tests in utm".
    
    # Let's revert to the manual input loop but keep the SSH *capability* commented out 
    # or available if manual input is empty.
    
    while True:
        try:
            print("\nWaiting for request hex from online-only (Guest)...")
            req_hex = input("Paste Request: ").strip()
            if not req_hex:
                break
            
            print("Processing in Host Vault...")
            resp_hex, err = run_host_command(
                "./virtual-fido offline-only --auto-approve",
                req_hex + "\n\n"
            )
            
            if err:
                print(f"Vault Error: {err}")
            
            lines = resp_hex.splitlines()
            actual_resp = ""
            for line in reversed(lines):
                if len(line) > 10 and all(c in "0123456789abcdefABCDEF" for c in line):
                    actual_resp = line
                    break
            
            if actual_resp:
                print(f"Response: {actual_resp}")
                print("Paste this back into the Guest relay.")
            else:
                print("Could not find response hex in vault output.")
                print(resp_hex)
                
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    main()
